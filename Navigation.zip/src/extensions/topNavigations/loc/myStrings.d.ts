declare interface ITopNavigationsApplicationCustomizerStrings {
  Title: string;
}

declare module 'TopNavigationsApplicationCustomizerStrings' {
  const strings: ITopNavigationsApplicationCustomizerStrings;
  export = strings;
}
