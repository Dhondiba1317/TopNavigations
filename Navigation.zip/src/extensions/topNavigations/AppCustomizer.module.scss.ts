/* tslint:disable */
require("./AppCustomizer.module.css");
const styles = {
  app: 'app_b37d48d9',
  top: 'top_b37d48d9',
  bottom: 'bottom_b37d48d9',
  'ms-SPLegacyFabricBlock': 'ms-SPLegacyFabricBlock_b37d48d9',
  'headerRow-49': 'headerRow-49_b37d48d9',
  menu: 'menu_b37d48d9',
  bottommenu: 'bottommenu_b37d48d9',
  active: 'active_b37d48d9',
  submenu: 'submenu_b37d48d9',
  bottomPlaceholderContainer: 'bottomPlaceholderContainer_b37d48d9',
  'bottom-placeholder-container': 'bottom-placeholder-container_b37d48d9',
  'bottom-menu': 'bottom-menu_b37d48d9',
  'sub-menu': 'sub-menu_b37d48d9'
};

export default styles;
/* tslint:enable */