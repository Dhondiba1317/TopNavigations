define([], function() {
  return {
    "Title": "TopNavigationsApplicationCustomizer"
  }
});