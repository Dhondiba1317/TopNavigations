declare const styles: {
    app: string;
    top: string;
    bottom: string;
    'ms-SPLegacyFabricBlock': string;
    'headerRow-49': string;
    menu: string;
    bottommenu: string;
    active: string;
    submenu: string;
    bottomPlaceholderContainer: string;
    'bottom-placeholder-container': string;
    'bottom-menu': string;
    'sub-menu': string;
};
export default styles;
//# sourceMappingURL=AppCustomizer.module.scss.d.ts.map