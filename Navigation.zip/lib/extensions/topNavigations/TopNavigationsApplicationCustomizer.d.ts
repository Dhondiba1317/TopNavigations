import { BaseApplicationCustomizer } from '@microsoft/sp-application-base';
export interface ITopNavigationsApplicationCustomizerProperties {
    NavigationList: string;
    Top: string;
    Bottom: string;
}
export default class TopNavigationsApplicationCustomizer extends BaseApplicationCustomizer<ITopNavigationsApplicationCustomizerProperties> {
    private _topPlaceholder;
    private _bottomPlaceholder;
    private _navigationData;
    onInit(): Promise<void>;
    private _fetchNavigationData;
    private _renderPlaceholders;
    private _onDispose;
    private _createNavigationMenu;
    private _createMenuItem;
}
//# sourceMappingURL=TopNavigationsApplicationCustomizer.d.ts.map